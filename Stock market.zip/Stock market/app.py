import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import plotly.graph_objs as go
from data_fetcher import StockDataFetcher
from config import REFRESH_INTERVAL, SYMBOLS

app = dash.Dash(__name__)

app.layout = html.Div([
    html.H1('Real-Time Stock Insights Dashboard', style={'textAlign': 'center'}),
    dcc.Interval(
        id='interval-component',
        interval=REFRESH_INTERVAL*1000,
        n_intervals=0
    ),
    html.Div(id='stock-graphs', className='row'),
    html.Div([
        html.Div(id='sentiment-analysis', className='six columns'),
        html.Div(id='news-feed', className='six columns')
    ], className='row')
])

@app.callback(
    Output('stock-graphs', 'children'),
    [Input('interval-component', 'n_intervals')]
)
def update_stock_graphs(n):
    fetcher = StockDataFetcher()
    graphs = []
    
    for symbol in SYMBOLS:
        data = fetcher.get_realtime_data(symbol)
        if data is not None:
            fig = go.Figure(
                go.Ohlc(x=data.index,
                        open=data['1. open'],
                        high=data['2. high'],
                        low=data['3. low'],
                        close=data['4. close'])
            )
            fig.update_layout(title=f'{symbol} Realtime Prices')
            graphs.append(dcc.Graph(figure=fig))
    
    return graphs

app.run(debug=True, port=8051)