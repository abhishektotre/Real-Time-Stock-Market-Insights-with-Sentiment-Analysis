import os
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv('ALPHA_VANTAGE_API_KEY')
REFRESH_INTERVAL = 60  # Seconds
SYMBOLS = ['MSFT', 'AAPL', 'GOOGL']