import os
from alpha_vantage.timeseries import TimeSeries
import pandas as pd
from textblob import TextBlob
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from config import API_KEY

class StockDataFetcher:
    def __init__(self):
        self.ts = TimeSeries(key=API_KEY, output_format='pandas')
        self.sia = SentimentIntensityAnalyzer()

    def get_realtime_data(self, symbol):
        try:
            data, meta_data = self.ts.get_quote_endpoint(symbol)
            return data
        except Exception as e:
            print(f"Error fetching data: {e}")
            return None

    def get_news(self, symbol):
        try:
            response = self.ts.get_news_headline(symbol)
            response.raise_for_status()
            return response.json().get('articles', [])[:5]
        except Exception as e:
            print(f"News API Error: {e}")
            return []

    def analyze_sentiment(self, text):
        blob = TextBlob(text)
        vader_scores = self.sia.polarity_scores(text)
        
        return {
            "textblob": {
                "polarity": blob.sentiment.polarity,
                "subjectivity": blob.sentiment.subjectivity
            },
            "vader": vader_scores
        }